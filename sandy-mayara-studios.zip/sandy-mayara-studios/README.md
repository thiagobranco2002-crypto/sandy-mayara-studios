# Sandy Mayara Studios - Landing Page

Landing page profissional para fotografia e filmagem de eventos, casamentos e produções audiovisuais.

## 🎨 Tecnologias Utilizadas

- **React 19** - Framework JavaScript
- **TypeScript** - Tipagem estática
- **Vite** - Build tool moderno
- **CSS3** - Estilização responsiva
- **Vercel** - Hospedagem e deploy

## 📱 Características

- ✨ Design elegante e responsivo
- 🎬 Galeria de portfólio interativa
- 📞 Integração com WhatsApp, Instagram e Email
- 🚀 Otimizado para SEO
- ⚡ Performance rápida
- 📱 Mobile-first approach

## 🚀 Deploy na Vercel

### Pré-requisitos

1. Conta no GitHub
2. Conta na Vercel (vercel.com)

### Passos para Deploy

1. **Fazer push do repositório para GitHub:**
   ```bash
   git remote add origin https://github.com/seu-usuario/sandy-mayara-studios.git
   git branch -M main
   git push -u origin main
   ```

2. **Conectar na Vercel:**
   - Acesse [vercel.com](https://vercel.com)
   - Clique em "New Project"
   - Selecione o repositório `sandy-mayara-studios`
   - Clique em "Deploy"

3. **Configurar Domínio (Opcional):**
   - Na dashboard da Vercel, vá para "Settings" > "Domains"
   - Adicione seu domínio personalizado
   - Siga as instruções para configurar os DNS

## 🔧 Desenvolvimento Local

### Instalação

```bash
pnpm install
```

### Executar em Desenvolvimento

```bash
pnpm dev
```

A página estará disponível em `http://localhost:5173`

### Build para Produção

```bash
pnpm build
```

## 📧 Contato

- **Email:** mayara.sandydasilva14@gmail.com
- **WhatsApp:** [47 99209-1856](https://wa.me/5547992091856)
- **Instagram:** [@asandymayara](https://instagram.com/asandymayara)

## 📄 Licença

© 2025 Sandy Mayara Studios. Todos os direitos reservados.
