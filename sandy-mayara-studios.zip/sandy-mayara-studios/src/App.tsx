import './App.css';

function App() {
  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="container">
          <div className="logo-section">
            <img src="/logo.jpg" alt="Sandy Mayara Studios" className="logo" />
          </div>
          <nav className="nav">
            <a href="#sobre" className="nav-link">Sobre</a>
            <a href="#portfolio" className="nav-link">Portfólio</a>
            <a href="#contato" className="nav-link">Contato</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <h1 className="hero-title">Capturando Momentos Inesquecíveis</h1>
          <p className="hero-subtitle">Fotografia e Filmagem Profissional para Eventos Especiais</p>
          <a href="#contato" className="cta-button">Solicite um Orçamento</a>
        </div>
      </section>

      {/* Sobre Section */}
      <section id="sobre" className="about">
        <div className="container">
          <div className="about-grid">
            <div className="about-image">
              <img src="/perfil.jpg" alt="Sandy Mayara - Fotógrafa" className="about-img" />
            </div>
            <div className="about-content">
              <h2>Sobre Sandy Mayara</h2>
              <p>
                Sou uma fotógrafa e videógrafa profissional apaixonada por contar histórias através de imagens. 
                Com anos de experiência em eventos, casamentos, ensaios e produções audiovisuais, meu objetivo é 
                capturar a essência e a emoção de cada momento único.
              </p>
              <p>
                Utilizo equipamentos de última geração e técnicas avançadas de iluminação e composição para 
                entregar resultados de qualidade excepcional. Cada projeto é tratado com dedicação e cuidado 
                especial para garantir sua satisfação.
              </p>
              <div className="services">
                <div className="service-item">
                  <span className="service-icon">📸</span>
                  <h3>Fotografia</h3>
                  <p>Retratos, eventos, casamentos e sessões de estúdio</p>
                </div>
                <div className="service-item">
                  <span className="service-icon">🎬</span>
                  <h3>Filmagem</h3>
                  <p>Vídeos profissionais e produções audiovisuais</p>
                </div>
                <div className="service-item">
                  <span className="service-icon">✨</span>
                  <h3>Edição</h3>
                  <p>Pós-produção e tratamento de imagens</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="portfolio">
        <div className="container">
          <h2 className="section-title">Portfólio</h2>
          <p className="section-subtitle">Conheça alguns dos meus trabalhos recentes</p>
          
          <div className="portfolio-grid">
            <div className="portfolio-item">
              <img src="/trabalho.jpg" alt="Filmagem em Evento" className="portfolio-img" />
              <div className="portfolio-overlay">
                <h3>Filmagem em Evento</h3>
                <p>Captura profissional de momentos especiais</p>
              </div>
            </div>
            <div className="portfolio-item">
              <img src="/retrato.jpg" alt="Retrato de Estúdio" className="portfolio-img" />
              <div className="portfolio-overlay">
                <h3>Retrato de Estúdio</h3>
                <p>Iluminação profissional e composição artística</p>
              </div>
            </div>
            <div className="portfolio-item">
              <img src="/perfil.jpg" alt="Fotografia Artística" className="portfolio-img" />
              <div className="portfolio-overlay">
                <h3>Fotografia Artística</h3>
                <p>Expressão criativa e sensibilidade visual</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contato" className="contact">
        <div className="container">
          <h2 className="section-title">Entre em Contato</h2>
          <p className="section-subtitle">Vamos criar algo extraordinário juntos</p>
          
          <div className="contact-grid">
            <div className="contact-card">
              <h3>WhatsApp</h3>
              <p>Envie uma mensagem direta</p>
              <a href="https://wa.me/5547992091856" target="_blank" rel="noopener noreferrer" className="contact-link">
                Conversar no WhatsApp
              </a>
            </div>
            <div className="contact-card">
              <h3>Instagram</h3>
              <p>Acompanhe meu trabalho</p>
              <a href="https://instagram.com/asandymayara" target="_blank" rel="noopener noreferrer" className="contact-link">
                @asandymayara
              </a>
            </div>
            <div className="contact-card">
              <h3>Email</h3>
              <p>Envie um email</p>
              <a href="mailto:contato@sandymayara.com" className="contact-link">
                contato@sandymayara.com
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <p>&copy; 2025 Sandy Mayara Studios. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
